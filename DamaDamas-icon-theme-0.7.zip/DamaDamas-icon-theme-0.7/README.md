![alt tag](https://i.hizliresim.com/D7k7M3.png)
![alt tag](https://i.hizliresim.com/Z919Vo.png)

# DamaDamas-Icon-Theme

## What Is DamaDamas-Icon-Theme?
Damadamas icon is a gnu icon based gpl-3.0 license, made up of all svg format files for linux distributions.

## How To Install?
If you have python3 and rsync in your distribution, you can configure the theme as you like and install it on your system.
By opening the terminal in the directory you downloaded the icons for installation.
![alt tag](https://i.hizliresim.com/vjojRr.gif)

```
sudo python3 damadamas-installer.py
```
Follow the steps by running the command.

Why sudo. sudo with / usr / share / icons and notice the icons on your system to notice the desktop.

```
python3 damadamas-installer.py
```
If you do not use sudo, the icons will be placed under username / .icons, which may cause some distributions not to see the icons.


Thanks for your support suggestions and criticisms.
